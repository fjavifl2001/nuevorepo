-- AlterEnum
ALTER TYPE "SetType" ADD VALUE 'MyorepMatchDown';
