-- AlterTable
ALTER TABLE "User" ADD COLUMN     "migratedFromV2" BOOL;
