-- AlterTable
ALTER TABLE "Workout" ADD COLUMN     "note" STRING;
