import Root from './separator.svelte';

export {
	Root,
	//
	Root as Separator
};
