<h3 class="-mt-2 mb-4 scroll-m-20 text-2xl font-semibold tracking-tight">
	<slot />
</h3>
