<div class="flex w-full grow flex-col items-center justify-center gap-2">
	<span class="text-4xl font-bold">You're offline</span>
	<h3 class="font-light">We don't yet support offline mode</h3>
</div>
