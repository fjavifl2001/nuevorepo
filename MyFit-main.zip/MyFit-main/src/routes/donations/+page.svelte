<div class="prose prose-neutral max-w-none dark:prose-invert lg:prose-lg">
	<h1>Donations</h1>

	<div class="grid grid-cols-2 items-center">
		<span class="font-bold">GitHub Sponsors</span>
		<span class="font-bold">Buy Me A Coffee</span>
		<iframe src="https://github.com/sponsors/WhyAsh5114/button" class="h-8 w-32" title="Sponsor WhyAsh5114"></iframe>
		<a href="https://www.buymeacoffee.com/WhyAsh5114" aria-label="Buy me a coffee">
			<img
				alt="buy me a coffee link"
				class="!m-0"
				src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=☕&slug=WhyAsh5114&button_colour=5F7FFF&font_colour=ffffff&font_family=Inter&outline_colour=000000&coffee_colour=FFDD00"
			/>
		</a>
	</div>

	<h2>How MyFit started</h2>
	<p>
		I'm just a college student who started MyFit as a fun side project. I never thought I'd actually get users 😅. My
		original intention was just to have an app for personal use and as a resume project to help me get a software
		engineering job. Over time, this project grew and gained a handful of users, which made me unreasonably happy.
	</p>

	<h2>Why you shouldn't donate</h2>
	<p>
		Please don't feel obliged to donate. I know how it feels to not have, or not feel like spending, over $20 for a
		simple workout tracking app. To be honest, I don't think I'll even need donations soon, as the free tiers offered by
		my hosting providers are really generous and the user base is still small. You simply using the app, logging
		workouts, giving feedback, or perhaps starring this repository on GitHub is more than enough for me 😊.
	</p>

	<h2>Why you should donate</h2>
	<p>
		If you've used the app for quite some time, you genuinely enjoyed it, and feel like I deserve a free diet coke!
		You'll get some extra benefits such as: issue prioritization and early access to features.
	</p>

	<h2>How donations will be used</h2>
	<p>
		The primary way donations to MyFit will be used is for hosting the project (Vercel) and its database (CockroachDB).
		If any are left over, it'll simply motivate me to work on this project further and improve it in every way possible.
	</p>
</div>
